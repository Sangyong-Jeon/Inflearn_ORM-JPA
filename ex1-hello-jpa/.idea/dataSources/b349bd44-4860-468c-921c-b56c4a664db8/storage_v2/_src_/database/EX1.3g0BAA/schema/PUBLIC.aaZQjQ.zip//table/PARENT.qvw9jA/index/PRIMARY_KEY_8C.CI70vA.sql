create unique index PRIMARY_KEY_8C
    on PARENT (ID);


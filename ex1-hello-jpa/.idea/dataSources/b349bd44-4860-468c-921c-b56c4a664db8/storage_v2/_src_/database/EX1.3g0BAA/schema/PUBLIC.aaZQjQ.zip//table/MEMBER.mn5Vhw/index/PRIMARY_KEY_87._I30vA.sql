create unique index PRIMARY_KEY_87
    on MEMBER (MEMBER_ID);


create unique index PRIMARY_KEY_1
    on BOOK (ID);


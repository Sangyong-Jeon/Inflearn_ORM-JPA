create unique index PRIMARY_KEY_E8
    on MEMBERPRODUCT (ID);


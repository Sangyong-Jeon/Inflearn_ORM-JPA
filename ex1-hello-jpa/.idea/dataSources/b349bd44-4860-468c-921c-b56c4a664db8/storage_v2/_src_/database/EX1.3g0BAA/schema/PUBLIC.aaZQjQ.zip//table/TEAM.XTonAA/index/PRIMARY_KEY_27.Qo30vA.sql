create unique index PRIMARY_KEY_27
    on TEAM (TEAM_ID);

